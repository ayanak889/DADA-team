class MealPlanner {
    constructor() {
        this.apiKey = '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'; // User's actual key
        this.apiEndpoint = 'https://api.openai.com/v1/chat/completions';
    }

    async validateApiKey() {
        if (!this.apiKey || this.apiKey === 'YOUR_OPENAI_API_KEY_HERE') {
            console.error('OpenAI API key is not set correctly. Please ensure it is replaced in js/ai.js.');
            throw new Error('OpenAI API key is not configured in the code.');
        }
        try {
            const response = await fetch(this.apiEndpoint, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${this.apiKey}`
                },
                body: JSON.stringify({
                    model: "gpt-4o-mini",
                    messages: [
                        {
                            role: "system",
                            content: "Test message"
                        }
                    ],
                    max_tokens: 5,
                    response_format: { type: "json_object" } // Add JSON mode for validation ping
                })
            });
            if (!response.ok) {
                if (response.status === 401) {
                     console.error('OpenAI API key is invalid or unauthorized.');
                     throw new Error('Provided OpenAI API key is invalid or lacks permissions.');
                }
                throw new Error('Failed to validate API key with OpenAI.');
            }
            return true;
        } catch (error) {
            console.error('API key validation error:', error.message);
            throw new Error(error.message || 'Invalid API key. Please check your key and try again.');
        }
    }

    async generateMealPlan(calories, restrictions = [], mealCount = 3) {
        if (!this.apiKey) {
            throw new Error('OpenAI API key is not set. Please set it in the settings.');
        }

        const restrictionsText = restrictions.length > 0 
            ? `Ensure the meal plan is suitable for someone with the following restrictions: ${restrictions.join(', ')}.` 
            : '';

        const prompt = `Generate a ${mealCount}-meal plan for a daily calorie intake of ${calories} calories. ${restrictionsText}
        For each meal, provide:
        1. Meal name (string, as "name")
        2. Ingredients list (array of strings, as "ingredients")
        3. Preparation steps (array of strings, as "preparation")
        4. Calorie count (number, as "calories")
        5. Macronutrient breakdown (object with protein, carbs, fat as numbers, key "macronutrients")
        The entire response must be a single JSON object. The root object must have a single key "meals" which is an array of these meal objects. Example meal structure: { "name": "Chicken Salad", "ingredients": ["chicken breast", "lettuce"], "preparation": ["Cook chicken", "Mix ingredients"], "calories": 300, "macronutrients": { "protein": 30, "carbs": 10, "fat": 15 } }.`;

        try {
            const response = await fetch(this.apiEndpoint, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${this.apiKey}`
                },
                body: JSON.stringify({
                    model: "gpt-4o-mini",
                    messages: [
                        {
                            role: "system",
                            content: "You are a professional nutritionist and chef. You will provide meal plans formatted strictly as a single JSON object. The root object will contain a 'meals' array, where each element is a meal object with specific fields as requested by the user."
                        },
                        {
                            role: "user",
                            content: prompt
                        }
                    ],
                    temperature: 0.5, // Slightly lower temperature for more deterministic JSON
                    max_tokens: 2000,  // Increased max_tokens
                    response_format: { type: "json_object" } // Enable JSON mode
                })
            });

            if (!response.ok) {
                const errorData = await response.text();
                console.error("OpenAI API Error Details:", errorData);
                throw new Error(`Failed to generate meal plan. Status: ${response.status}.`);
            }

            const data = await response.json(); // This should be safe if JSON mode works
            // In JSON mode, data.choices[0].message.content should already be a parsed JSON object if the model behaves perfectly,
            // or a stringified JSON. The OpenAI library usually handles this. If it's a string, parse it.
            let mealPlanContent = data.choices[0].message.content;
            if (typeof mealPlanContent === 'string') {
                return this.parseMealPlan(mealPlanContent);
            }
            return mealPlanContent; // If it's already an object (due to future library versions or specific model behavior)

        } catch (error) {
            console.error('Error generating meal plan:', error);
            throw error;
        }
    }

    parseMealPlan(content) {
        try {
            return JSON.parse(content);
        } catch (error) {
            console.error("Failed to parse meal plan content. Raw content received:", content);
            // If parsing fails, try to extract JSON from the text (less likely needed with JSON mode)
            const jsonMatch = content.match(/\{[\s\S]*\}/);
            if (jsonMatch && jsonMatch[0]) {
                try {
                    return JSON.parse(jsonMatch[0]);
                } catch (regexParseError) {
                    console.error("Failed to parse extracted JSON from regex. Extracted content:", jsonMatch[0]);
                    throw new Error('Meal plan response was not valid JSON even after attempting to extract. Original error: ' + error.message);
                }
            }
            throw new Error('Meal plan response was not valid JSON. Original error: ' + error.message);
        }
    }

    formatMealPlan(mealPlanData) {
        // Ensure mealPlanData and mealPlanData.meals exist before trying to map
        if (!mealPlanData || !mealPlanData.meals || !Array.isArray(mealPlanData.meals)) {
            console.error("Invalid meal plan data structure for formatting:", mealPlanData);
            return '<p class="error">Received an invalid meal plan structure from AI.</p>';
        }

        return mealPlanData.meals.map(meal => {
            // Basic validation for meal object properties
            const name = meal.name || 'Unnamed Meal';
            const calories = meal.calories || 'N/A';
            const protein = meal.macronutrients && meal.macronutrients.protein !== undefined ? meal.macronutrients.protein : 'N/A';
            const carbs = meal.macronutrients && meal.macronutrients.carbs !== undefined ? meal.macronutrients.carbs : 'N/A';
            const fat = meal.macronutrients && meal.macronutrients.fat !== undefined ? meal.macronutrients.fat : 'N/A';
            const ingredients = Array.isArray(meal.ingredients) ? meal.ingredients.map(ingredient => `<li>${ingredient}</li>`).join('') : '<li>Ingredients not available</li>';
            const preparation = Array.isArray(meal.preparation) ? meal.preparation.map(step => `<li>${step}</li>`).join('') : '<li>Preparation steps not available</li>';

            return `
            <div class="meal-card">
                <h3>${name}</h3>
                <div class="meal-details">
                    <p><strong>Calories:</strong> ${calories}</p>
                    <p><strong>Macronutrients:</strong></p>
                    <ul>
                        <li>Protein: ${protein}g</li>
                        <li>Carbs: ${carbs}g</li>
                        <li>Fat: ${fat}g</li>
                    </ul>
                    <p><strong>Ingredients:</strong></p>
                    <ul>
                        ${ingredients}
                    </ul>
                    <p><strong>Preparation:</strong></p>
                    <ol>
                        ${preparation}
                    </ol>
                </div>
            </div>
        `}).join('');
    }
}

window.MealPlanner = MealPlanner; 