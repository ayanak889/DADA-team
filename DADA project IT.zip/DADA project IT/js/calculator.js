class WeightCalculator {
    constructor() {
        this.MIN_CALORIE_DEFICIT = 500; // Minimum daily calorie deficit for weight loss
        this.MAX_CALORIE_DEFICIT = 1000; // Maximum daily calorie deficit for weight loss
        this.SAFE_WEIGHT_LOSS_PER_WEEK = 0.5; // Safe weight loss in kg per week
    }

    calculateBMR(weight, height, age, gender = 'male') {
        // Using Mifflin-St Jeor Equation
        const baseBMR = 10 * weight + 6.25 * height - 5 * age;
        return gender === 'male' ? baseBMR + 5 : baseBMR - 161;
    }

    calculateTDEE(bmr, activityLevel) {
        return bmr * activityLevel;
    }

    calculateCalorieNeeds(currentWeight, targetWeight, height, age, activityLevel, gender = 'male') {
        const bmr = this.calculateBMR(currentWeight, height, age, gender);
        const tdee = this.calculateTDEE(bmr, activityLevel);
        
        const weightDifference = currentWeight - targetWeight;
        const weeksToGoal = Math.abs(weightDifference) / this.SAFE_WEIGHT_LOSS_PER_WEEK;
        
        let dailyCalorieAdjustment;
        if (weightDifference > 0) { // Weight loss
            dailyCalorieAdjustment = -Math.min(
                this.MAX_CALORIE_DEFICIT,
                Math.max(this.MIN_CALORIE_DEFICIT, (weightDifference * 7700) / (weeksToGoal * 7))
            );
        } else if (weightDifference < 0) { // Weight gain
            dailyCalorieAdjustment = Math.min(
                this.MAX_CALORIE_DEFICIT,
                Math.max(this.MIN_CALORIE_DEFICIT, (Math.abs(weightDifference) * 7700) / (weeksToGoal * 7))
            );
        } else {
            dailyCalorieAdjustment = 0;
        }

        return {
            bmr: Math.round(bmr),
            tdee: Math.round(tdee),
            dailyCalories: Math.round(tdee + dailyCalorieAdjustment),
            weeksToGoal: Math.round(weeksToGoal),
            dailyCalorieAdjustment: Math.round(dailyCalorieAdjustment)
        };
    }

    calculateMacronutrients(dailyCalories, goal = 'weight_loss') {
        let proteinPercentage, fatPercentage, carbPercentage;

        switch (goal) {
            case 'weight_loss':
                proteinPercentage = 0.4; // 40% protein
                fatPercentage = 0.35;    // 35% fat
                carbPercentage = 0.25;   // 25% carbs
                break;
            case 'weight_gain':
                proteinPercentage = 0.3; // 30% protein
                fatPercentage = 0.25;    // 25% fat
                carbPercentage = 0.45;   // 45% carbs
                break;
            default: // maintenance
                proteinPercentage = 0.3; // 30% protein
                fatPercentage = 0.3;     // 30% fat
                carbPercentage = 0.4;    // 40% carbs
        }

        return {
            protein: Math.round((dailyCalories * proteinPercentage) / 4), // 4 calories per gram of protein
            fat: Math.round((dailyCalories * fatPercentage) / 9),        // 9 calories per gram of fat
            carbs: Math.round((dailyCalories * carbPercentage) / 4)      // 4 calories per gram of carbs
        };
    }
}

// Export the calculator class
window.WeightCalculator = WeightCalculator; 