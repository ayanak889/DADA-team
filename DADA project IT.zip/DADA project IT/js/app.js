document.addEventListener('DOMContentLoaded', async () => {
    const calculator = new WeightCalculator();
    const mealPlanner = new MealPlanner();
    
    const weightForm = document.getElementById('weightForm');
    const resultsSection = document.querySelector('.results-section');
    const calorieResult = document.getElementById('calorieResult');
    const mealPlanResult = document.getElementById('mealPlanResult');
    const generateMoreBtn = document.getElementById('generateMoreBtn');

    // API key is now hardcoded in ai.js, so no need for prompt or localStorage check
    // try {
    //     await mealPlanner.validateApiKey(); // You might still want to validate on load
    // } catch (error) {
    //     alert(error.message);
    //     // Potentially disable functionality if key is invalid
    // }

    weightForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        // Show loading state
        resultsSection.style.display = 'block';
        calorieResult.innerHTML = '<div class="loading"></div>';
        mealPlanResult.innerHTML = '<div class="loading"></div>';

        try {
            // Get form values
            const currentWeight = parseFloat(document.getElementById('currentWeight').value);
            const targetWeight = parseFloat(document.getElementById('targetWeight').value);
            const height = parseFloat(document.getElementById('height').value);
            const age = parseInt(document.getElementById('age').value);
            const activityLevel = parseFloat(document.getElementById('activityLevel').value);

            // Get selected allergies/restrictions
            const restrictions = Array.from(document.querySelectorAll('input[name="allergy"]:checked'))
                .map(checkbox => checkbox.value);

            // Calculate calorie needs
            const calorieNeeds = calculator.calculateCalorieNeeds(
                currentWeight,
                targetWeight,
                height,
                age,
                activityLevel
            );

            // Calculate macronutrients
            const macros = calculator.calculateMacronutrients(
                calorieNeeds.dailyCalories,
                currentWeight > targetWeight ? 'weight_loss' : 'weight_gain'
            );

            // Display calorie results
            calorieResult.innerHTML = `
                <div class="calorie-summary">
                    <h4>Daily Calorie Requirements</h4>
                    <p><strong>BMR:</strong> ${calorieNeeds.bmr} calories</p>
                    <p><strong>TDEE:</strong> ${calorieNeeds.tdee} calories</p>
                    <p><strong>Daily Target:</strong> ${calorieNeeds.dailyCalories} calories</p>
                    <p><strong>Estimated weeks to goal:</strong> ${calorieNeeds.weeksToGoal}</p>
                    
                    <h4>Macronutrient Breakdown</h4>
                    <p><strong>Protein:</strong> ${macros.protein}g</p>
                    <p><strong>Carbs:</strong> ${macros.carbs}g</p>
                    <p><strong>Fat:</strong> ${macros.fat}g</p>
                </div>
            `;

            // Generate and display meal plan
            const mealPlan = await mealPlanner.generateMealPlan(
                calorieNeeds.dailyCalories,
                restrictions
            );
            mealPlanResult.innerHTML = mealPlanner.formatMealPlan(mealPlan);

        } catch (error) {
            console.error('Error:', error);
            calorieResult.innerHTML = `<p class="error">Error: ${error.message}</p>`;
            mealPlanResult.innerHTML = `<p class="error">Error generating meal plan. Please try again.</p>`;
        }
    });

    generateMoreBtn.addEventListener('click', async () => {
        try {
            const currentCalories = parseInt(calorieResult.querySelector('.calorie-summary p:nth-child(3)').textContent.match(/\d+/)[0]);
            const restrictions = Array.from(document.querySelectorAll('input[name="allergy"]:checked'))
                .map(checkbox => checkbox.value);

            mealPlanResult.innerHTML = '<div class="loading"></div>';
            const mealPlan = await mealPlanner.generateMealPlan(currentCalories, restrictions);
            mealPlanResult.innerHTML = mealPlanner.formatMealPlan(mealPlan);
        } catch (error) {
            console.error('Error:', error);
            mealPlanResult.innerHTML = `<p class="error">Error generating new meal plan. Please try again.</p>`;
        }
    });
}); 