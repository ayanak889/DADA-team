# Weight Management & Meal Planning Assistant

This web application helps users achieve their weight goals by providing personalized meal plans and recipes based on their current weight, target weight, and dietary restrictions.

## Features

- Weight goal calculator
- Calorie requirement calculator
- Personalized meal recommendations
- Allergy-aware recipe filtering
- AI-powered meal suggestions
- Responsive design

## Technologies Used

- HTML5
- CSS3
- JavaScript
- OpenAI API for AI-powered recommendations
- Local Storage for user preferences

## Setup Instructions

1. Clone this repository
2. Open `index.html` in your web browser
3. Enter your OpenAI API key in the settings (required for AI recommendations)

## Project Structure

```
├── index.html          # Main application page
├── css/
│   └── styles.css      # Styling
├── js/
│   ├── app.js         # Main application logic
│   ├── calculator.js  # Weight and calorie calculations
│   └── ai.js          # AI integration
└── README.md          # This file
```

## Usage

1. Enter your current weight and target weight
2. Select any allergies or dietary restrictions
3. Get personalized meal recommendations and calorie requirements
4. Browse through AI-generated recipe suggestions

## Note

This application requires an OpenAI API key to function properly. Please obtain one from OpenAI's website and enter it in the settings. 